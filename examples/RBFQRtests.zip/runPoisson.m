close all
clear all
setPaths;

%
% An RBF-FD example for solving the Poisson equation. Collocation and LS
% unfitted or fitted methods.
%

pars.dim = 2;                            % dim = 1,2 or 3
pars.display = 0;                        % Plot solution
pars.geom = 'ball';                      % ball or cube
pars.mode = 'unfitted';                  % fitted, unfitted or collocation
pars.bcMode = 'weak';                    % strong or weak imposition of boundary conditions (only relevant for fitted)
pars.scaling = 1;                        % Include scaling of the unfitted LS problem
pars.mvCentres = 1;                      % Option to have a Y point on top of all X points inside the domain
pars.q = 6;                              % Oversampling
                             % Number of center points (X) in each patch
pars.ep = 0.1;                           % Not relevant for 'r3' basis
pars.phi = 'rbfqr';                      % Choice of basis 'r3', 'mq', 'gs', 'iq', 'rbfqr'
pars.psi = 'wendland_c2';                % Weight function: wendland_c2 or bump
pars.pdeg = -1;                          % Polynomial extension, not relevant for 'rbfqr'
pars.del = 0.2;                          % Overlap between patches

order = 2:7;
P = 4:2:20;
P = P.^pars.dim;      
for i = 1:length(order)
    pars.N = nchoosek(order(i)+pars.dim,pars.dim);
    for j = 1:length(P)
        pars.P = P(j);                          % Number of patches
        [l2Error(i,j), h(i,j)] = RBFPUM_Poisson(pars);
    end
end

figure(); 
for i = 1:length(order)
    loglog(h(i,:),l2Error(i,:),'DisplayName',strcat("p = ", int2str(order(i))))
    legend
    hold on;
    p = polyfit(log(h(i,:)),log(l2Error(i,:)),1);
    disp(['Order is ',num2str(p(1))])
end
